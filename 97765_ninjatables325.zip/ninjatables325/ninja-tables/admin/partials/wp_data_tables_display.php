<div class="table_data_press" id="data-tables-app"></div>

<style id="table_designer_css">
</style>

<style id="ninja_table_designer_common_css">
</style>